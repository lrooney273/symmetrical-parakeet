<script>
     import Item from './Item.svelte';
     let newItem;
     let toDoList = [];
     let count = [];

     function addToList() {
          if (!newItem) return;
          toDoList = [...toDoList, {
               text: newItem,
               checked: false,
          }];
          newItem = '';
     }
     function removeFromList(n) {
          toDoList.splice(n, 1);
          toDoList = toDoList;
     }
     function toggleDone(index,v) {
          v = !v;
          toDoList[index].checked = v;
          toDoList = toDoList;
     }
</script>

<form on:submit|preventDefault={addToList}>
     <input bind:value={newItem}>
</form>
<ul>
     {#each toDoList as item, index}
     <Item 
          text={item.text}
          checked={item.checked} 
          toggleDone={() => toggleDone(index, item.checked)}
          removeItem={() => removeFromList(index)}
     />
     {/each}
</ul>

<style>
     ul{
          list-style: none;
          padding-left: 0;
          content: center;
          margin-left: 20em;
          margin-right: 20em;
          border-width: 1em;
          border-style: groove;
     }
</style>