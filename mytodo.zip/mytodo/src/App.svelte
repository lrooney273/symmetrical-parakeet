<script>
	import Todo from './ToDo.svelte';
</script>

<main>
	<div class="title1">
	<h1 class="mainTitle">D&D Combat Tracker!</h1>
	</div>
	<Todo/>
</main>

<style>
	main {
		text-align: center;
		padding: 1em;
		margin: 0 auto;
		
	}

	@media (min-width: 1051px) {
		main {
			min-width: none;
		}
		.mainTitle{
			font-size: 3em;
		}
	}
	@media (max-width: 1050px) {
		main {
			max-width: none;
		}
		.mainTitle{
			font-size: 2em;
		}
	}
	@media (max-width: 847px) {
		main {
			max-width: none;
		}
		.mainTitle{
			font-size: 1em;
		}
	}
</style>